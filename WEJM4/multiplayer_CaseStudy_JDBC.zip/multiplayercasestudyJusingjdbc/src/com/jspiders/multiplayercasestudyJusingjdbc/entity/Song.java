package com.jspiders.multiplayercasestudyJusingjdbc.entity;

public class Song {

}
